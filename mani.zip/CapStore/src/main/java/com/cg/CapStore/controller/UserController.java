package com.cg.CapStore.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CapStore.model.CartDTO;
import com.cg.CapStore.model.UserDTO;
import com.cg.CapStore.repository.CartRepository;
import com.cg.CapStore.repository.UserRepository;

@RestController
@RequestMapping("api/v1/")
public class UserController {
	
	
	@Autowired
	UserRepository userRepository;
	
	@RequestMapping(value = "USER", method = RequestMethod.GET)
	public List<UserDTO> list() {
		return userRepository.findAll();
	}

	@RequestMapping(value = "USER", method = RequestMethod.POST)
	public UserDTO create(@RequestBody UserDTO USER) {
	 return userRepository.saveAndFlush(USER);
	}

	@RequestMapping(value = "USER/{EMAILID}", method = RequestMethod.GET)
	public UserDTO get(@PathVariable String id) {
		return userRepository.findOne(id);
	}

	@RequestMapping(value = "USER/{EMAILID}", method = RequestMethod.PUT)
	public UserDTO update(@PathVariable String id, @RequestBody UserDTO USER) 
	{
		UserDTO existingUser = userRepository.findOne(id);
		BeanUtils.copyProperties(USER, existingUser);
		return userRepository.saveAndFlush(existingUser);
	}

	@RequestMapping(value = "USER/{EMAILID}", method = RequestMethod.DELETE)
	public UserDTO delete(@PathVariable String id) {
		UserDTO existingUser = userRepository.findOne(id);
		userRepository.delete(existingUser);
		return existingUser;
	}
	

}
