package com.cg.CapStore.controller;

	import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CapStore.model.OrderDTO;
import com.cg.CapStore.repository.OrderRepository;


	//import com.boot.model.Shipwreck;
	//import com.boot.repository.ShipwreckRepository;

	@RestController
	@RequestMapping("api/v1/")
	public class OrderController {
		
		@Autowired
		//private ShipwreckRepository shipwreckRepository;
		private OrderRepository orderRepository;
		
		
		@RequestMapping(value = "order", method = RequestMethod.GET)
		public List<OrderDTO> list() {
			return orderRepository.findAll();
		}

		@RequestMapping(value = "order", method = RequestMethod.POST)
		public OrderDTO create(@RequestBody OrderDTO order) {
			return orderRepository.saveAndFlush(order);
		}

		@RequestMapping(value = "order/{orderId}", method = RequestMethod.GET)
		public OrderDTO get(@PathVariable Integer id) {
			return orderRepository.findOne(id);
		}

		@RequestMapping(value = "order/{orderId}", method = RequestMethod.PUT)
		public OrderDTO update(@PathVariable Integer id, @RequestBody OrderDTO order) {
			OrderDTO existingOrder = orderRepository.findOne(id);
			BeanUtils.copyProperties(order, existingOrder);
			return orderRepository.saveAndFlush(existingOrder);
		}

		@RequestMapping(value = "order/{orderId}", method = RequestMethod.DELETE)
		public OrderDTO delete(@PathVariable Integer id) {
			OrderDTO existingOrder = orderRepository.findOne(id);
			orderRepository.delete(existingOrder);
			return existingOrder;
		}
		

		
	}



