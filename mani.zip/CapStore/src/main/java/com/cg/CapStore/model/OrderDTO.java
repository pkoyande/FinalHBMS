package com.cg.CapStore.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="orderdetail")
public class OrderDTO {

	@Id
	@Column(name="orderid")
	private int orderId;
	
	
	
	@Column(name="orderdate")
	private Date orderDate;
	@Column(name="productquantity")
	private int productQuantity;
	@Column(name="totalprice")
	private int totalPrice;
	@Column(name="finalprice")
	private int finalPrice;
	
	
	
	@ManyToOne(targetEntity = CustomerDTO.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "customerid", updatable=false, insertable= false)
	private CustomerDTO customer;
	
	
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "merchantid", updatable=false, insertable= false)
	private MerchantDTO merchant;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "productid", updatable=false, insertable= false)
	private ProductDTO product;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(int finalPrice) {
		this.finalPrice = finalPrice;
	}
	public CustomerDTO getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDTO customer) {
		this.customer = customer;
	}
	public MerchantDTO getMerchant() {
		return merchant;
	}
	public void setMerchant(MerchantDTO merchant) {
		this.merchant = merchant;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	
	
}
