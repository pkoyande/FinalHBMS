package com.cg.CapStore.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CapStore.model.CartDTO;
import com.cg.CapStore.repository.CartRepository;

@RestController
@RequestMapping("api/v1/")
public class CartController {
	
	
	@Autowired
	CartRepository cartRepository;
	
	@RequestMapping(value = "cart", method = RequestMethod.GET)
	public List<CartDTO> list() {
		return cartRepository.findAll();
	}

	/*@RequestMapping(value = "cart", method = RequestMethod.POST)
	public CartDTO create(@RequestBody CartDTO cart) {
	 return cartRepository.saveAndFlush(cart);
	}*/

	@RequestMapping(value = "cart/{customerId}", method = RequestMethod.GET)
	public CartDTO get(@PathVariable Integer id) {
		return cartRepository.findOne(id);
	}
	
	

	@RequestMapping(value = "cart/{customerId}", method = RequestMethod.PUT)
	public CartDTO update(@PathVariable Integer id, @RequestBody CartDTO cart) 
	{
		CartDTO existingCart = cartRepository.findOne(id);
		BeanUtils.copyProperties(cart, existingCart);
		return cartRepository.saveAndFlush(existingCart);
	}

	@RequestMapping(value = "cart/{customerId}", method = RequestMethod.DELETE)
	public CartDTO delete(@PathVariable Integer id) {
		CartDTO existingCart = cartRepository.findOne(id);
		cartRepository.delete(existingCart);
		return existingCart;
	}
	

}
