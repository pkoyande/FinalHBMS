package com.cg.CapStore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.CapStore.model.UserDTO;

public interface UserRepository extends JpaRepository<UserDTO, String>{

}
