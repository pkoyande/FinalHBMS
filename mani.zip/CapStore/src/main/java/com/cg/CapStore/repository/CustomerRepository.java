package com.cg.CapStore.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.cg.CapStore.model.CustomerDTO;



public interface CustomerRepository extends  JpaRepository<CustomerDTO, Integer> {
	
	/* @Query
	 * (value = "SELECT * FROM CART WHERE CUSTOMERID = ?1", nativeQuery = true)
	 CustomerDTO getCustomerId(int customerId);*/ 
}
